﻿namespace FlappyBirdGame_Nayab_Shafaq_Ayesha
{
    partial class ExitWinfowForm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RestrtBtn = new System.Windows.Forms.Button();
            this.Exitbtn = new System.Windows.Forms.Button();
            this.GameOvertxt = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // RestrtBtn
            // 
            this.RestrtBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(154)))), ((int)(((byte)(0)))));
            this.RestrtBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RestrtBtn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.RestrtBtn.Location = new System.Drawing.Point(417, 212);
            this.RestrtBtn.Name = "RestrtBtn";
            this.RestrtBtn.Size = new System.Drawing.Size(139, 73);
            this.RestrtBtn.TabIndex = 7;
            this.RestrtBtn.Text = "Share";
            this.RestrtBtn.UseVisualStyleBackColor = false;
            this.RestrtBtn.Click += new System.EventHandler(this.RestrtBtn_Click);
            // 
            // Exitbtn
            // 
            this.Exitbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(154)))), ((int)(((byte)(0)))));
            this.Exitbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exitbtn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Exitbtn.Location = new System.Drawing.Point(241, 212);
            this.Exitbtn.Name = "Exitbtn";
            this.Exitbtn.Size = new System.Drawing.Size(139, 73);
            this.Exitbtn.TabIndex = 6;
            this.Exitbtn.Text = "Exit";
            this.Exitbtn.UseVisualStyleBackColor = false;
            this.Exitbtn.Click += new System.EventHandler(this.Exitbtn_Click);
            // 
            // GameOvertxt
            // 
            this.GameOvertxt.AutoSize = true;
            this.GameOvertxt.BackColor = System.Drawing.Color.Transparent;
            this.GameOvertxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GameOvertxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(189)))), ((int)(((byte)(52)))));
            this.GameOvertxt.Location = new System.Drawing.Point(231, 113);
            this.GameOvertxt.Name = "GameOvertxt";
            this.GameOvertxt.Size = new System.Drawing.Size(337, 55);
            this.GameOvertxt.TabIndex = 5;
            this.GameOvertxt.Text = "GAME OVER!";
            // 
            // ExitWinfowForm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::FlappyBirdGame_Nayab_Shafaq_Ayesha.Properties.Resources.background_img;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.RestrtBtn);
            this.Controls.Add(this.Exitbtn);
            this.Controls.Add(this.GameOvertxt);
            this.DoubleBuffered = true;
            this.Name = "ExitWinfowForm2";
            this.Text = "ExitWinfowForm2";
            this.Load += new System.EventHandler(this.ExitWinfowForm2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button RestrtBtn;
        private System.Windows.Forms.Button Exitbtn;
        private System.Windows.Forms.Label GameOvertxt;
    }
}