﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlappyBirdGame_Nayab_Shafaq_Ayesha
{
    public partial class Form1 : Form
    {
        // Variables
        
        private int speed = 8;
        int gravity = 5;
        
        private int score = 0;
        public Form1()
        {
            InitializeComponent(); 
            timer1.Interval = 20;
            score = 0;
        }
        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            Bird.Top += gravity;
            Pipedown1.Left -= speed;
            Pipedown3.Left -= speed;
            Pipedown2.Left -= speed;
            Pipeup1.Left -= speed;
            Pipeup2.Left -= speed;
            Pipeup3.Left -= speed;
            Score.Text = "score: " + score.ToString();

            if(Pipedown1.Left<=-10)
            {
                Pipedown1.Left = 600;
                score++;
            }
            if (Pipedown2.Left <= -10)
            {
                Pipedown2.Left = 600;
                score++;
            }
            if (Pipedown3.Left <= -10)
            {
                Pipedown3.Left = 600;
                score++;
            }
            if (Pipeup1.Left <= -10)
            {
                Pipeup1.Left = 650;
                
            }
            if (Pipeup2.Left <= -10)
            {
                Pipeup2.Left = 650;
                
            }
            if (Pipeup3.Left <= -10)
            {
                Pipeup3.Left = 650;
                
            }
            if (Bird.Bounds.IntersectsWith(Pipedown1.Bounds) || Bird.Bounds.IntersectsWith(Pipedown2.Bounds) || Bird.Bounds.IntersectsWith(Pipedown3.Bounds) ||
               Bird.Bounds.IntersectsWith(Pipeup1.Bounds) || Bird.Bounds.IntersectsWith(Pipeup2.Bounds) || Bird.Bounds.IntersectsWith(Pipeup3.Bounds) || 
               Bird.Bounds.IntersectsWith(ground.Bounds) || Bird.Top<-25)
            {
                endgame();
            }
            if (score >= 5)
            {
                speed = 15;
            }
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            
            if (e.KeyCode == Keys.Down)
                 gravity = 5;
        }
        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
                gravity = -5;
        }
        private void endgame()
        {
            timer1.Stop();
            Score.Text += "";
            ExitWinfowForm2 frm = new ExitWinfowForm2();
            frm.Show();
            frm.Focus();
        }
    }
}
