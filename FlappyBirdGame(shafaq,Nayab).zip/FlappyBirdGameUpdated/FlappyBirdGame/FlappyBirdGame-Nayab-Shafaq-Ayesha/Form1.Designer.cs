﻿namespace FlappyBirdGame_Nayab_Shafaq_Ayesha
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Score = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.ground = new System.Windows.Forms.PictureBox();
            this.Pipeup3 = new System.Windows.Forms.PictureBox();
            this.Pipeup2 = new System.Windows.Forms.PictureBox();
            this.Pipeup1 = new System.Windows.Forms.PictureBox();
            this.Pipedown3 = new System.Windows.Forms.PictureBox();
            this.Pipedown2 = new System.Windows.Forms.PictureBox();
            this.Pipedown1 = new System.Windows.Forms.PictureBox();
            this.Bird = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ground)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pipeup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pipeup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pipeup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pipedown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pipedown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pipedown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bird)).BeginInit();
            this.SuspendLayout();
            // 
            // Score
            // 
            this.Score.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Score.AutoSize = true;
            this.Score.BackColor = System.Drawing.Color.Transparent;
            this.Score.Font = new System.Drawing.Font("Arial", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Score.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Score.Location = new System.Drawing.Point(1164, 7);
            this.Score.Name = "Score";
            this.Score.Size = new System.Drawing.Size(154, 41);
            this.Score.TabIndex = 23;
            this.Score.Text = "Score: 0";
            this.Score.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 20;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // ground
            // 
            this.ground.BackColor = System.Drawing.Color.Transparent;
            this.ground.Image = global::FlappyBirdGame_Nayab_Shafaq_Ayesha.Properties.Resources.background_img___Copy1;
            this.ground.Location = new System.Drawing.Point(-9, 588);
            this.ground.Name = "ground";
            this.ground.Size = new System.Drawing.Size(1379, 161);
            this.ground.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ground.TabIndex = 24;
            this.ground.TabStop = false;
            // 
            // Pipeup3
            // 
            this.Pipeup3.BackColor = System.Drawing.Color.Transparent;
            this.Pipeup3.Image = global::FlappyBirdGame_Nayab_Shafaq_Ayesha.Properties.Resources.pipe;
            this.Pipeup3.Location = new System.Drawing.Point(696, 388);
            this.Pipeup3.Name = "Pipeup3";
            this.Pipeup3.Size = new System.Drawing.Size(63, 216);
            this.Pipeup3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pipeup3.TabIndex = 22;
            this.Pipeup3.TabStop = false;
            // 
            // Pipeup2
            // 
            this.Pipeup2.BackColor = System.Drawing.Color.Transparent;
            this.Pipeup2.Image = global::FlappyBirdGame_Nayab_Shafaq_Ayesha.Properties.Resources.pipe;
            this.Pipeup2.Location = new System.Drawing.Point(522, 438);
            this.Pipeup2.Name = "Pipeup2";
            this.Pipeup2.Size = new System.Drawing.Size(51, 165);
            this.Pipeup2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pipeup2.TabIndex = 21;
            this.Pipeup2.TabStop = false;
            // 
            // Pipeup1
            // 
            this.Pipeup1.BackColor = System.Drawing.Color.Transparent;
            this.Pipeup1.Image = global::FlappyBirdGame_Nayab_Shafaq_Ayesha.Properties.Resources.pipe;
            this.Pipeup1.Location = new System.Drawing.Point(354, 454);
            this.Pipeup1.Name = "Pipeup1";
            this.Pipeup1.Size = new System.Drawing.Size(63, 151);
            this.Pipeup1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pipeup1.TabIndex = 20;
            this.Pipeup1.TabStop = false;
            // 
            // Pipedown3
            // 
            this.Pipedown3.BackColor = System.Drawing.Color.Transparent;
            this.Pipedown3.Image = global::FlappyBirdGame_Nayab_Shafaq_Ayesha.Properties.Resources.pipedown;
            this.Pipedown3.Location = new System.Drawing.Point(696, 0);
            this.Pipedown3.Name = "Pipedown3";
            this.Pipedown3.Size = new System.Drawing.Size(63, 134);
            this.Pipedown3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pipedown3.TabIndex = 19;
            this.Pipedown3.TabStop = false;
            // 
            // Pipedown2
            // 
            this.Pipedown2.BackColor = System.Drawing.Color.Transparent;
            this.Pipedown2.Image = global::FlappyBirdGame_Nayab_Shafaq_Ayesha.Properties.Resources.pipedown;
            this.Pipedown2.Location = new System.Drawing.Point(522, 0);
            this.Pipedown2.Name = "Pipedown2";
            this.Pipedown2.Size = new System.Drawing.Size(51, 242);
            this.Pipedown2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pipedown2.TabIndex = 18;
            this.Pipedown2.TabStop = false;
            // 
            // Pipedown1
            // 
            this.Pipedown1.BackColor = System.Drawing.Color.Transparent;
            this.Pipedown1.Image = global::FlappyBirdGame_Nayab_Shafaq_Ayesha.Properties.Resources.pipedown;
            this.Pipedown1.Location = new System.Drawing.Point(354, 0);
            this.Pipedown1.Name = "Pipedown1";
            this.Pipedown1.Size = new System.Drawing.Size(63, 227);
            this.Pipedown1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pipedown1.TabIndex = 16;
            this.Pipedown1.TabStop = false;
            // 
            // Bird
            // 
            this.Bird.BackColor = System.Drawing.Color.Transparent;
            this.Bird.Image = global::FlappyBirdGame_Nayab_Shafaq_Ayesha.Properties.Resources.LiKr8B4XT1;
            this.Bird.Location = new System.Drawing.Point(127, 286);
            this.Bird.Margin = new System.Windows.Forms.Padding(0);
            this.Bird.Name = "Bird";
            this.Bird.Size = new System.Drawing.Size(90, 69);
            this.Bird.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Bird.TabIndex = 17;
            this.Bird.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(224)))), ((int)(((byte)(255)))));
            this.BackgroundImage = global::FlappyBirdGame_Nayab_Shafaq_Ayesha.Properties.Resources.background_img;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.Pipeup1);
            this.Controls.Add(this.Pipeup2);
            this.Controls.Add(this.Pipeup3);
            this.Controls.Add(this.ground);
            this.Controls.Add(this.Score);
            this.Controls.Add(this.Pipedown3);
            this.Controls.Add(this.Pipedown2);
            this.Controls.Add(this.Pipedown1);
            this.Controls.Add(this.Bird);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(-215, -42);
            this.Name = "Form1";
            this.Text = "Flappy Bird";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.ground)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pipeup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pipeup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pipeup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pipedown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pipedown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pipedown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bird)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Score;
        private System.Windows.Forms.PictureBox Pipeup3;
        private System.Windows.Forms.PictureBox Pipeup2;
        private System.Windows.Forms.PictureBox Pipeup1;
        private System.Windows.Forms.PictureBox Pipedown3;
        private System.Windows.Forms.PictureBox Pipedown2;
        private System.Windows.Forms.PictureBox Bird;
        private System.Windows.Forms.PictureBox Pipedown1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox ground;
    }
}

